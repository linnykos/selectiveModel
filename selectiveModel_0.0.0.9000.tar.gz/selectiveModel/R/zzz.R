Rcpp::loadModule("module", TRUE)

#' Some unneeded documentation
#'
#' @docType methods
#' @name Rcpp_Plane
#' @aliases Rcpp_Plane-class
#' @rdname Rcpp_Plane
#' @export
NULL

#' Some unneeded documentation
#'
#' @name Plane
NULL

