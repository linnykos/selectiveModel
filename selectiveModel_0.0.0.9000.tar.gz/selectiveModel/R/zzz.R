Rcpp::loadModule("module", TRUE)
