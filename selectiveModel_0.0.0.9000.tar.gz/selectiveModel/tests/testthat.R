library(testthat)
library(selectiveModel)

test_check("selectiveModel")
